# 2044-numpy-analisis-numerico-eficiente-con-python
Este repositorio corresponde al entrenamiento de Numpy: Análisis numérico eficiente con Python de Alura Latam.
