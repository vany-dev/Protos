const h1 = <h2>Hello, world!</h2>;
ReactDOM.render(h1, document.getElementById('root'));