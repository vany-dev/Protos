# HOC (High Orden Component)
- Pasa lógica reutilizable a componentes
- Componente que retorna otro componente
- Es modular y simple

## Usos        
- Usado por apollo y redux
