export interface CredencialesTipo {
  usuario: string;
  clave: string;
}
