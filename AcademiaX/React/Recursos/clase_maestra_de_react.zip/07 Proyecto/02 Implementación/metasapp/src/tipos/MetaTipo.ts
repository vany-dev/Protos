export interface MetaTipo {
  id: number;
  icono: string;
  eventos: number;
  periodo: number;
  detalles: string;
  meta: number;
  completado: number;
}
