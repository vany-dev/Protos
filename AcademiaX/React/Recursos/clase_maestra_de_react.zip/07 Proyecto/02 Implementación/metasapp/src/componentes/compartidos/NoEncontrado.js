import React from "react";

function NoEncontrado() {
  return <p>No Encontrado</p>;
}

export default NoEncontrado;
