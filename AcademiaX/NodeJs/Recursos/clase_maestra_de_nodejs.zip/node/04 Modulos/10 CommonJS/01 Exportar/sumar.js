function sumar(a, b) {
    return a + b;
}

module.exports = { sumar, numero: 10 };