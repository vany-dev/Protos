// app.js
const { obtenerAleatorio } = require('./operaciones');

console.log('Número aleatorio:', obtenerAleatorio());
