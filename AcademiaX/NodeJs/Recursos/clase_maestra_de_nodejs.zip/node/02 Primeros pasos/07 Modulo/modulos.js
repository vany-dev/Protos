const path = require('path');
console.log(__dirname);
console.log(__filename);
console.log(path.basename(__filename));